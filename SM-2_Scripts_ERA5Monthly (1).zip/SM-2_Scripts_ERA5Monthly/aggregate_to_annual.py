#!/usr/bin/env python3
"""aggregate_to_annual.py

Aggregates monthly pseudo-labels (Pb/Pl) to annual totals and means.

Input:
  - outputs/pseudo_labels_monthly.csv produced by mechanistic_productivity_monthly.py

Output:
  - outputs/pseudo_labels_annual.csv

Usage:
  python aggregate_to_annual.py --input outputs/pseudo_labels_monthly.csv --out outputs/pseudo_labels_annual.csv
"""

import argparse
import os
import pandas as pd


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="Monthly pseudo-labels CSV")
    ap.add_argument("--out", required=True, help="Annual output CSV path")
    args = ap.parse_args()

    df = pd.read_csv(args.input)
    for c in ["year", "Pb_g_m2_month", "Pl_g_m2_month", "Pb_g_m2_d", "Pl_g_m2_d"]:
        if c not in df.columns:
            raise ValueError(f"Missing required column: {c}")

    annual = df.groupby("year", as_index=False).agg(
        Pb_sum_g_m2_y=("Pb_g_m2_month", "sum"),
        Pl_sum_g_m2_y=("Pl_g_m2_month", "sum"),
        Pb_mean_g_m2_d=("Pb_g_m2_d", "mean"),
        Pl_mean_g_m2_d=("Pl_g_m2_d", "mean"),
        n_months=("year", "count"),
    )

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    annual.to_csv(args.out, index=False)
    print(f"Saved annual summary to: {args.out}")


if __name__ == "__main__":
    main()