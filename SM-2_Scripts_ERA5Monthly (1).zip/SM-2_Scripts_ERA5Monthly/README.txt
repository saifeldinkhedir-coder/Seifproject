SM-2_Scripts (Monthly ERA5-Land dataset) - Supplementary Material
===============================================================

This package adapts the Supplementary scripts to your real ERA5-Land *monthly* extracted dataset:
  ERA5Land_PortSudan_Circle_19385ha_2018_2025_Monthly.csv

Dataset columns detected
------------------------
- month (YYYY-MM)
- t2m_c (degC)
- rh2m (%)
- ws10m (m/s)
- solar_mj_m2_day (MJ m^-2 day^-1)

Pipeline scripts
----------------
1) mechanistic_productivity_monthly.py
   - Converts solar radiation to a PAR proxy (mol photons m^-2 day^-1)
   - Computes modifiers f(T), f_env
   - Computes Pb and Pl (daily) and converts to monthly totals

2) aggregate_to_annual.py
   - Aggregates monthly Pb/Pl to annual totals and mean daily rates

3) ml_emulator_random_forest_monthly.py
   - Trains a Random Forest emulator for the selected target column

Quick start
-----------
Option A (one command):
  python run_all_monthly_pipeline.py

Option B (step-by-step):
  python mechanistic_productivity_monthly.py --input data/ERA5Land_PortSudan_Circle_19385ha_2018_2025_Monthly.csv --out outputs/pseudo_labels_monthly.csv
  python aggregate_to_annual.py --input outputs/pseudo_labels_monthly.csv --out outputs/pseudo_labels_annual.csv
  python ml_emulator_random_forest_monthly.py --input outputs/pseudo_labels_monthly.csv --target Pb_g_m2_d --outdir outputs

Notes
-----
- The PAR conversion is a proxy:
    PAR_mol = solar_mj_m2_day * 0.45 * 4.57
  Adjust parameters if your manuscript uses a different radiation-to-PAR conversion.
- Update eta and lipid_content to match the manuscript values.