#!/usr/bin/env python3
"""ml_emulator_random_forest_monthly.py

Random Forest regression pipeline to emulate monthly productivity pseudo-labels.

Input:
  - Monthly pseudo-labels CSV produced by mechanistic_productivity_monthly.py

Targets:
  - Pb_g_m2_d or Pl_g_m2_d (daily rates inferred from monthly ERA5-Land predictors)
  - Alternatively, Pb_g_m2_month / Pl_g_m2_month

Usage:
  python ml_emulator_random_forest_monthly.py --input outputs/pseudo_labels_monthly.csv --target Pb_g_m2_d --outdir outputs
"""

import argparse
import os
import json
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold, cross_val_score, train_test_split
from sklearn.metrics import mean_absolute_error, r2_score
import joblib


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="Monthly pseudo-labels CSV")
    ap.add_argument("--target", default="Pb_g_m2_d", help="Target column")
    ap.add_argument("--outdir", required=True, help="Output directory")
    ap.add_argument("--n_estimators", type=int, default=600)
    ap.add_argument("--max_depth", type=int, default=None)
    ap.add_argument("--random_state", type=int, default=42)
    args = ap.parse_args()

    df = pd.read_csv(args.input)

    predictors = ["t2m_c", "rh2m_pct", "ws10m_m_s", "solar_mj_m2_day", "par_mol_m2_day_proxy"]
    for c in predictors + [args.target]:
        if c not in df.columns:
            raise ValueError(f"Missing column: {c}")

    X = df[predictors].to_numpy(dtype=float)
    y = df[args.target].to_numpy(dtype=float)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=args.random_state
    )

    model = RandomForestRegressor(
        n_estimators=args.n_estimators,
        max_depth=args.max_depth,
        random_state=args.random_state,
        n_jobs=-1,
    )
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    mae = mean_absolute_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)

    kf = KFold(n_splits=5, shuffle=True, random_state=args.random_state)
    cv_r2 = cross_val_score(model, X, y, cv=kf, scoring="r2")

    os.makedirs(args.outdir, exist_ok=True)
    metrics_path = os.path.join(args.outdir, f"rf_monthly_metrics_{args.target}.json")
    with open(metrics_path, "w", encoding="utf-8") as f:
        json.dump({
            "target": args.target,
            "mae_test": float(mae),
            "r2_test": float(r2),
            "cv_r2_mean": float(np.mean(cv_r2)),
            "cv_r2_std": float(np.std(cv_r2)),
            "n_estimators": args.n_estimators,
            "max_depth": args.max_depth,
            "predictors": predictors,
        }, f, indent=2)

    model_path = os.path.join(args.outdir, f"rf_monthly_model_{args.target}.joblib")
    joblib.dump(model, model_path)

    print(f"Saved model: {model_path}")
    print(f"Saved metrics: {metrics_path}")
    print(f"Test MAE={mae:.4f}, R2={r2:.4f}, CV R2 mean={np.mean(cv_r2):.4f}")


if __name__ == "__main__":
    main()