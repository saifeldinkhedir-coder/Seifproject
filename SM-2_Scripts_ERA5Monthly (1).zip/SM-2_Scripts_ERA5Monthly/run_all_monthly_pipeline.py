#!/usr/bin/env python3
"""run_all_monthly_pipeline.py

One-command driver to run the monthly pipeline on the provided ERA5-Land monthly dataset.

Usage:
  python run_all_monthly_pipeline.py

It will create:
  outputs/pseudo_labels_monthly.csv
  outputs/pseudo_labels_annual.csv
  outputs/rf_monthly_model_Pb_g_m2_d.joblib and metrics json
"""

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    inp = ROOT / "data" / "ERA5Land_PortSudan_Circle_19385ha_2018_2025_Monthly.csv"
    pseudo_month = ROOT / "outputs" / "pseudo_labels_monthly.csv"
    pseudo_year = ROOT / "outputs" / "pseudo_labels_annual.csv"
    outdir = ROOT / "outputs"

    subprocess.check_call([sys.executable, str(ROOT / "mechanistic_productivity_monthly.py"),
                           "--input", str(inp),
                           "--out", str(pseudo_month)])
    subprocess.check_call([sys.executable, str(ROOT / "aggregate_to_annual.py"),
                           "--input", str(pseudo_month),
                           "--out", str(pseudo_year)])
    subprocess.check_call([sys.executable, str(ROOT / "ml_emulator_random_forest_monthly.py"),
                           "--input", str(pseudo_month),
                           "--target", "Pb_g_m2_d",
                           "--outdir", str(outdir)])

if __name__ == "__main__":
    main()