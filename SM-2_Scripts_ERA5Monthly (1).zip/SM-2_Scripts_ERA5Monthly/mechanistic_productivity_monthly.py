#!/usr/bin/env python3
"""mechanistic_productivity_monthly.py

Mechanistic (literature-inspired) productivity formulation adapted for a MONTHLY ERA5-Land dataset.

This script:
  1) Reads monthly ERA5-Land summary data (e.g., Port Sudan circle 19,385 ha, 2018–2025).
  2) Converts solar radiation (MJ m^-2 day^-1) to a PAR proxy (mol photons m^-2 day^-1).
  3) Computes daily areal biomass productivity Pb (g m^-2 d^-1) and lipid productivity Pl (g m^-2 d^-1):
        Pb = eta * PAR * f(T) * f_env
        Pl = Pb * LC
  4) Converts to monthly totals using days in each month.

Input columns (expected; auto-mapped):
  - month (YYYY-MM)
  - t2m_c (degC)
  - rh2m (%%)
  - ws10m (m/s)
  - solar_mj_m2_day (MJ m^-2 day^-1)

PAR conversion (default proxy):
  PAR_MJ = 0.45 * Solar_MJ
  PAR_mol = PAR_MJ * 4.57
Where 0.45 is the typical PAR fraction of shortwave radiation and 4.57 mol/MJ is an energy-to-photon conversion
factor for PAR. Adjust if your manuscript uses different conventions.

Usage:
  python mechanistic_productivity_monthly.py \
    --input data/ERA5Land_PortSudan_Circle_19385ha_2018_2025_Monthly.csv \
    --out outputs/pseudo_labels_monthly.csv

Outputs:
  - pseudo_labels_monthly.csv containing:
      month, year, days_in_month, predictors, PAR proxy, modifiers, Pb_g_m2_d, Pl_g_m2_d,
      Pb_g_m2_month, Pl_g_m2_month
"""

import argparse
import os
import pandas as pd
import numpy as np


def f_temperature(t_c: np.ndarray, t_opt: float = 28.0, t_width: float = 10.0) -> np.ndarray:
    return np.exp(-((t_c - t_opt) ** 2) / (2.0 * (t_width ** 2)))


def f_environment(wind_m_s: np.ndarray, rh_pct: np.ndarray, wind_ref: float = 5.0, rh_ref: float = 60.0) -> np.ndarray:
    wind_term = 1.0 / (1.0 + np.maximum(wind_m_s - wind_ref, 0.0) / wind_ref)
    rh_term = 1.0 / (1.0 + np.maximum(rh_ref - rh_pct, 0.0) / 40.0)
    return np.clip(wind_term * rh_term, 0.0, 1.0)


def solar_to_par_mol(solar_mj_m2_day: np.ndarray, par_fraction: float = 0.45, mol_per_mj_par: float = 4.57) -> np.ndarray:
    par_mj = par_fraction * solar_mj_m2_day
    return par_mj * mol_per_mj_par


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True, help="Monthly ERA5-Land CSV")
    ap.add_argument("--out", required=True, help="Output CSV path")
    ap.add_argument("--eta", type=float, default=0.55, help="Empirical photosynthetic conversion efficiency")
    ap.add_argument("--lipid_content", type=float, default=0.25, help="Lipid content fraction (0-1)")
    ap.add_argument("--t_opt", type=float, default=28.0, help="Optimum temperature (degC)")
    ap.add_argument("--t_width", type=float, default=10.0, help="Temperature response width (degC)")
    ap.add_argument("--par_fraction", type=float, default=0.45, help="Fraction of solar shortwave that is PAR (proxy)")
    ap.add_argument("--mol_per_mj_par", type=float, default=4.57, help="mol photons per MJ PAR")
    args = ap.parse_args()

    df = pd.read_csv(args.input)

    # Required fields in this dataset
    required = ["month", "t2m_c", "rh2m", "ws10m", "solar_mj_m2_day"]
    for c in required:
        if c not in df.columns:
            raise ValueError(f"Missing required column: {c}")

    df["month"] = pd.to_datetime(df["month"] + "-01")
    df["year"] = df["month"].dt.year
    df["month_str"] = df["month"].dt.to_period("M").astype(str)
    df["days_in_month"] = df["month"].dt.days_in_month

    t = df["t2m_c"].to_numpy(dtype=float)
    rh = df["rh2m"].to_numpy(dtype=float)
    wind = df["ws10m"].to_numpy(dtype=float)
    solar = df["solar_mj_m2_day"].to_numpy(dtype=float)

    par = solar_to_par_mol(solar, par_fraction=args.par_fraction, mol_per_mj_par=args.mol_per_mj_par)

    ft = f_temperature(t, t_opt=args.t_opt, t_width=args.t_width)
    fenv = f_environment(wind, rh)

    pb_d = np.maximum(args.eta * par * ft * fenv, 0.0)
    pl_d = np.maximum(pb_d * args.lipid_content, 0.0)

    pb_m = pb_d * df["days_in_month"].to_numpy(dtype=float)
    pl_m = pl_d * df["days_in_month"].to_numpy(dtype=float)

    out = pd.DataFrame({
        "month": df["month_str"],
        "year": df["year"],
        "days_in_month": df["days_in_month"],
        "t2m_c": df["t2m_c"],
        "rh2m_pct": df["rh2m"],
        "ws10m_m_s": df["ws10m"],
        "solar_mj_m2_day": df["solar_mj_m2_day"],
        "par_mol_m2_day_proxy": par,
        "f_T": ft,
        "f_env": fenv,
        "Pb_g_m2_d": pb_d,
        "Pl_g_m2_d": pl_d,
        "Pb_g_m2_month": pb_m,
        "Pl_g_m2_month": pl_m,
    })

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    out.to_csv(args.out, index=False)
    print(f"Saved monthly pseudo-labels to: {args.out}")


if __name__ == "__main__":
    main()